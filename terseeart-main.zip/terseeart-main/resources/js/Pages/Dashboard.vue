<template>
    <div>
        <h1>Welcome to Tabler Dashboard</h1>
    </div>
</template>
