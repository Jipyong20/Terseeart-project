<template>
  <div>
    <nav>
      <!-- Your Navigation Here -->
    </nav>

    <div class="container">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AdminLayout',
};
</script>

<style scoped>
/* Add your CSS styling for the layout here */
</style>
